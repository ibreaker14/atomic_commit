var searchData=
[
  ['transaction',['Transaction',['../class_transaction.html#a5d7d6a577b29410831c5da557c8391dd',1,'Transaction']]]
];
