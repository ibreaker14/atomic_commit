var searchData=
[
  ['get',['get',['../class_chord.html#a3e0b4e9a1af09a0604be7eecea716cba',1,'Chord']]],
  ['getfileguid',['getFileGUID',['../class_transaction.html#ae92bfe32ea302a118014421695d031b3',1,'Transaction']]],
  ['getfilestream',['getFileStream',['../class_transaction.html#acf3a4c149d94fda9402cff9ed4329a1a',1,'Transaction']]],
  ['getid',['getId',['../class_chord.html#a3dfb600d109b7d23459a3353af0274a9',1,'Chord.getId()'],['../class_transaction.html#a4c776b759d5bafc1c24643f2b873a87a',1,'Transaction.getID()']]],
  ['getoperation',['getOperation',['../class_transaction.html#ac39daba9505adb7d116d61889646692e',1,'Transaction']]],
  ['getpredecessor',['getPredecessor',['../class_chord.html#a3f1aadce3820e808c80662bb61a58e34',1,'Chord']]],
  ['gettimestamp',['getTimestamp',['../class_transaction.html#a3ccfd5004a6a118bbab964cdd452eabd',1,'Transaction']]],
  ['getvote',['getVote',['../class_transaction.html#a0c71a419c323aadb9da138e0d4750f32',1,'Transaction']]]
];
