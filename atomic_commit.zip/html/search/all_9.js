var searchData=
[
  ['newreadtimestamp',['newReadTimestamp',['../class_chord.html#a322356ee21b23fc843ea002723bbf439',1,'Chord']]],
  ['newwritetimestamp',['newWriteTimestamp',['../class_chord.html#a3f40aadac8a49b15e745a26b857cd616',1,'Chord']]],
  ['notify',['notify',['../class_chord.html#a4de8b8464782dd96d88deeb35b2f27a2',1,'Chord']]]
];
